from Ayudas import ObtenerNumeroPacientes, PacienteTiene

def Diagnostico(tos, fiebre, dolor_cabeza, dolor_garganta,
                ojos_rojos, malestar_general, dificultad_respirar):
    # TODO

no_pacientes = ObtenerNumeroPacientes()

# TODO
